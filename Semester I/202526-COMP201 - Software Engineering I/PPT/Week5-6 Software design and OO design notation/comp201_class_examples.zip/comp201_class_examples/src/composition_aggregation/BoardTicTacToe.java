package composition_aggregation;

import java.util.Random;

public class BoardTicTacToe implements IGameBoard {
	private static final int ROWS=3;
	private static final int COLS=3;

	private Square allSquares[][]=new Square[ROWS][COLS];	// squares are composition into this board
	
	private Player player1,player2;		// Players are aggregated into board
	
	private SquareValue player1TurnValue=SquareValue.Nought;
	private SquareValue player2TurnValue=SquareValue.Cross;
	
	private int currentPlayer=1;		// the current player who's turn it is
	
	private Player playerWon;			// which player has won
	
	/**
	 * Create new board with all blank values
	 */
	public BoardTicTacToe(Player player1,Player player2) {
		this.player1=player1;
		this.player2=player2;
		for (int row=0;row<ROWS;row++) {
			for (int col=0;col<COLS;col++) {
				allSquares[row][col]=new Square(SquareValue.Blank);
			}
		}
	}
	
	/* (non-Javadoc)
	 * @see composition_aggregation.IGameBoard#takeTurn(int, int)
	 */
	@Override
	public boolean takeTurn(int row,int col) {
		if (allSquares[row][col].getValue()!=SquareValue.Blank) return(false);
		switch (currentPlayer) {
		case 1 : allSquares[row][col]=new Square(this.player1TurnValue);
			currentPlayer=2;
			break;
		case 2 : allSquares[row][col]=new Square(this.player2TurnValue); 
			currentPlayer=1;
			break;
		}
		return(true);
	}
	/* (non-Javadoc)
	 * @see composition_aggregation.IGameBoard#takeRandomTurn()
	 */
	@Override
	public void takeRandomTurn() {
		Random rng=new Random(System.currentTimeMillis());
		int col=rng.nextInt(COLS);
		int row=rng.nextInt(ROWS);
		int count=COLS*ROWS;
		while (allSquares[row][col].getValue()!=SquareValue.Blank) {
			col++;
			if (col==COLS) {
				col=0;row++;
				if (row==ROWS) {
					row=0;
				}
			}
			count--;
			if (count==0) return;	// failed to find position to put random go
		}
		takeTurn(row, col);
	}
	
	/**
	 * Return which player won the game
	 * @param value  Which colour value won
	 * @return  the player who won
	 */
	private Player getPlayerWon(SquareValue value) {
		if (value==this.player1TurnValue) {
			return(player1);
		}
		if (value==this.player2TurnValue) {
			return(player2);
		}
		return(null);
	}
	
	
	/* (non-Javadoc)
	 * @see composition_aggregation.IGameBoard#gameOver()
	 */
	@Override
	public boolean gameOver() {
		for (int row=0;row<ROWS;row++) {
			SquareValue valueFirstPos=allSquares[row][0].getValue();
			if (valueFirstPos==SquareValue.Blank) continue;
			// check each col in turn going down rows
			for (int col=1;col<COLS;col++) {
				if (allSquares[row][col].getValue()!=valueFirstPos) {
					break;  // didn't win on this line
				}
				if (col==COLS-1) {
					// we won
					playerWon=getPlayerWon(valueFirstPos);
					return(true);
				}
			}
		}
		for (int col=0;col<COLS;col++) {
			SquareValue valueFirstPos=allSquares[0][col].getValue();
			if (valueFirstPos==SquareValue.Blank) continue;
			// check each rol in turn going across cols
			for (int row=1;row<ROWS;row++) {
				if (allSquares[row][col].getValue()!=valueFirstPos) {
					break;  // didn't win on this line
				}
				if (row==ROWS-1) {
					// we won
					playerWon=getPlayerWon(valueFirstPos);
					return(true);
				}
			}
		}
		// Now do diagonals
		SquareValue valueFirstPos=allSquares[0][0].getValue();
		for (int col=1;col<COLS;col++) {
			int row=col;
			if (valueFirstPos==SquareValue.Blank) break;
			if (allSquares[row][col].getValue()!=valueFirstPos) {
				break;  // didn't win on this line
			}
			if (row==ROWS-1) {
				// we won
				playerWon=getPlayerWon(valueFirstPos);
				return(true);
			}
		}
		valueFirstPos=allSquares[ROWS-1][0].getValue();
		for (int col=1;col<COLS;col++) {
			if (valueFirstPos==SquareValue.Blank) break;
			int row=ROWS-1-col;
			if (allSquares[row][col].getValue()!=valueFirstPos) {
				break;  // didn't win on this line
			}
			if (row==0) {
				// we won
				playerWon=getPlayerWon(valueFirstPos);
				return(true);
			}
		}
		// finally check for a draw
		int count=0;
		for (int col=0;col<COLS;col++) {
			for (int row=0;row<COLS;row++) {
					if (allSquares[row][col].getValue()!=SquareValue.Blank) {
						count++;
					}
			}
		}
		if (count==COLS*ROWS) return(true);
		return(false);
	}
	
	/* (non-Javadoc)
	 * @see composition_aggregation.IGameBoard#toString()
	 */
	@Override
	public String toString() {
		StringBuilder sb=new StringBuilder();
		for (int row=0;row<ROWS;row++) {
			for (int col=0;col<COLS;col++) {
				switch (allSquares[row][col].getValue()) {
					case Blank :
						sb.append(" ");
						break;
					case Nought :
						sb.append("O");
						break;
					case Cross :
						sb.append("X");
						break;
				}
				if (col!=COLS-1) {
					sb.append("|");
				}
			}
			sb.append("\n");
			if (row<ROWS-1) sb.append("-----\n");
		}
		if (this.gameOver()) {
			if (this.playerWon!=null) {
				sb.append("Player "+playerWon.getName()+" has won");
			} else {
				sb.append("Game ended in draw");
			}
		}
		sb.append("\n");sb.append("\n");
		return(sb.toString());
	}
	
}
