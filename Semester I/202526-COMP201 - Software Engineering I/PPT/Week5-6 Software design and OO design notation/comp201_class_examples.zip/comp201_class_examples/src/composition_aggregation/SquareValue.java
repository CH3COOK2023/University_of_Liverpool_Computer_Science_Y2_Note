package composition_aggregation;

public enum SquareValue {
	Nought,
	Cross,
	Blank

}
