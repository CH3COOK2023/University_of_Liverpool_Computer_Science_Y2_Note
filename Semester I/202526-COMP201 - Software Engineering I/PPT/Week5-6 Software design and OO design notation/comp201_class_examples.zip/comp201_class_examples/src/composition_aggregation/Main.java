package composition_aggregation;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Player player1=new Player("Alice");
		Player player2=new Player("Bob");
		IGameBoard board=new BoardTicTacToe(player1,player2);
		System.out.println(board.toString());
		while (!board.gameOver()) {
			board.takeRandomTurn();
			System.out.println(board.toString());	
		}
	}

}
