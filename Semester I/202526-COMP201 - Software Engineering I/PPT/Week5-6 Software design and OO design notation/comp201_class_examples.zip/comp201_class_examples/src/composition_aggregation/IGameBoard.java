package composition_aggregation;

public interface IGameBoard {

	/**
	 * Try and take a turn, returns false if turn was not valid
	 * i.e. if position is not blank
	 * @param row   Row position for turn
	 * @param col   Col position for turn
	 * @return  True if turn succesful otherwise false
	 */
	boolean takeTurn(int row, int col);

	/**
	 * Randomly chooses a position that hasn't been taken
	 */
	void takeRandomTurn();

	/**
	 * Returns true if TIC TAC TOE game has finished 
	 * @return  Finished game
	 */
	boolean gameOver();

	String toString();

}