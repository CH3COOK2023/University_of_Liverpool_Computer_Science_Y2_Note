package composition_aggregation;

public class Player {
	
	private String name;	// name of player
	private int score=0;	// score for player
	public Player(String name) {
		this.name=name;
	}
	
	public final void addToScore(int scoreAddAmount) {
		score+=scoreAddAmount;
	}
	
	
	/**
	 * Getter
	 * @return score for this player
	 */
	public final int getScore() {
		return(score);
	}
	
	public final String getName() {
		return(name);
	}

}
