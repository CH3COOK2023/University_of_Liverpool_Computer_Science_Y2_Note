package composition_aggregation;

/**
 * Represents square for Tic Tac Toe game (Noughts and Crosses)
 * @author SCoope
 *
 */
public class Square {
	private SquareValue value;
	public Square(SquareValue value) {
		this.value=value;
	}
	/**
	 * @return value of this square
	 */
	public SquareValue getValue() {
		return(value);
	}

}
