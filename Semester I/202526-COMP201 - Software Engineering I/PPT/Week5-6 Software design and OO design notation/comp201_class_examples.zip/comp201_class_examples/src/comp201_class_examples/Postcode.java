package comp201_class_examples;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Represents a UK postcode
 * Immutable
 * @author SCoope
 *
 */
public class Postcode {
	private String value;

	/**
	 * From stack overflow, regex example for postcode
	 */
	private static String regex = "^[A-Z]{1,2}[0-9R][0-9A-Z]? [0-9][ABD-HJLNP-UW-Z]{2}$";
	private static Pattern pattern = Pattern.compile(regex, Pattern.CASE_INSENSITIVE);

	public Postcode(String postcode) throws Exception {
		Matcher matcher=pattern.matcher(postcode);
		if (!matcher.matches()) {
			throw new Exception(" Bad postcode");
		}
		this.value=value;
	}
}
