package comp201_class_examples;

public interface IValidatable {
	public void validate() throws Exception;
}
