package comp201_class_examples;

public class Surname extends StringDataNonNull {

	private static final int MIN_LENGTH=4;
	
	public Surname(String string) throws Exception {
		super(string);
	}

	@Override
	protected void onValidate() throws Exception {
		if (super.getString().length()<MIN_LENGTH) {
			throw new Exception(this.getClass().getName()+" is too short min length is "+MIN_LENGTH);
		}
	}

}
