package comp201_class_examples;

public class Main {

	public static void main(String[] args) {
		
		try {
			Postcode code=new Postcode("PR9 0EL");
		} catch (Exception e) {
			System.err.println("Problem "+e.getMessage());
		}
		
		try {
			
			IValidatable surname=new Surname("Coope");
			IValidatable forename=new Forename("");
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			System.err.println("Problem "+e.getMessage());
			e.printStackTrace();
		}

	}

}
