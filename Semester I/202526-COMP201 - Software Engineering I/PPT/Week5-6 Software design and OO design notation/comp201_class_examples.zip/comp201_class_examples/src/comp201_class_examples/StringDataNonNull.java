package comp201_class_examples;

public abstract class StringDataNonNull implements IValidatable {
	private String string;

	public String getString() {
		return(string);
	}
	
	public StringDataNonNull(String string) throws Exception {
		this.string=string;
		validate();
	}
	
	protected abstract void onValidate() throws Exception;

	/**
	 * Validates the wrapped data and throws exception if data incorrect
	 */
	@Override
	public final void validate() throws Exception {
		if (string==null) {
			throw new Exception(this.getClass().getName()+" cannot be null");
		}
		if (string.length()==0) {
			throw new Exception(this.getClass().getName()+" cannot be zero length");
		}
		onValidate();
	}
}
