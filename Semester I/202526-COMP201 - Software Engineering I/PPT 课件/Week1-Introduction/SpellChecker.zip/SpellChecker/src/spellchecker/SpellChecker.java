package spellchecker;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class SpellChecker {
	SpellingNode root;
	public void loadWords(String fileName) {
		root=new SpellingNode();	// root of tree
		FileReader fr;
		try {
			fr = new FileReader(fileName);
			// TODO Auto-generated catch block
			BufferedReader br = new BufferedReader(fr);
			String nextWord=br.readLine();
	        while (nextWord!=null) {
	        	nextWord=nextWord.trim();
	        	root.addWord(nextWord);
	        	nextWord=br.readLine();
	        }
		} catch (FileNotFoundException e) {
			
			e.printStackTrace();
		} catch (IOException ioe) {
			
		}  
	}
	
	/** 
	 * Send word into tree to check for spelling
	 * @param word
	 * @return
	 */
	public boolean spellCheckWord(String word) {
		return(root.spellCheckWord(word));
	}
}
