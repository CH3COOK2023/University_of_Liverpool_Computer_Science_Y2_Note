package spellchecker;

public class Main {
	public static void main(String argvs[]) {
		System.out.println("Starting spell checker..");
		SpellChecker checker=new SpellChecker();
		checker.loadWords("dictionary\\words.en");
		System.out.println("Spelling check of cat is "+checker.spellCheckWord("cat"));
		System.out.println("Spelling check of  is "+checker.spellCheckWord("dog"));
		System.out.println("Spelling check of  is "+checker.spellCheckWord("sdgfrfgertg"));
	}
	
}
