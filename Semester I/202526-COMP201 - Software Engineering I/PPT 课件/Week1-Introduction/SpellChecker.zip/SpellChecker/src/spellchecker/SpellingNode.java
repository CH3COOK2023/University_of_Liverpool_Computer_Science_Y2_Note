package spellchecker;

import java.util.Hashtable;

public class SpellingNode {
	private Hashtable <Character,SpellingNode> nextNodes=new Hashtable<Character,SpellingNode>();
	
	// True if this node represents a recognised word
	// position in the tree
	private boolean wordNode=false;
	
	/**
	 * Adds a word to a dictionary tree
	 * @param word
	 */
	public void addWord(String word) {
		// If we've got to the end of the word, this is a word node
		if (word.length()==0) {
			wordNode=true;
			return;
		}
		Character nextCharacter=word.charAt(0);
		SpellingNode nextNode=nextNodes.get(nextCharacter);
		if (nextNode==null) {
			nextNode=new SpellingNode();
			nextNodes.put(nextCharacter,nextNode);
		} 
		nextNode.addWord(word.substring(1));
	}
	
	public boolean spellCheckWord(String word) {
		// If we reached the end of the word
		// is this code a word node
		
		if (word.length()==0) {
			return(wordNode);
		}
		Character nextCharacter=word.charAt(0);
		SpellingNode nextNode=nextNodes.get(nextCharacter);
		if (nextNode==null) {	// end of tree
			return(false);
		}
		return(nextNode.spellCheckWord(word.substring(1)));
	}
	
	public boolean isWordNode() {
		return(wordNode);
	}
}
