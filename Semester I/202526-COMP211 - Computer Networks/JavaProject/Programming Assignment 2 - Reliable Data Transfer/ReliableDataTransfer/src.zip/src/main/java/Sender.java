/*************************************
 * Filename:  Sender.java
 *************************************/

import java.util.*;

public class Sender extends NetworkHost {
    public int sequenceNumber;
    private List<String> messageQueue = new ArrayList<>();
    private Set<Integer> set = new HashSet<>();
    protected void Output(Message message) {
        boolean trigger = messageQueue.isEmpty();
        if(trigger)
            nextSequenceNumber();
        messageQueue.add(message.getData());
        if(trigger)
            sentPacket();
    }
    private void sentPacket(){
        if(messageQueue.isEmpty())
            return;
        Packet packet = new Packet(
                sequenceNumber,
                sequenceNumber,
                0,
                messageQueue.get(0)
        );
        packet.setChecksum(Verification.hash(packet));
        startTimer(AutoTest.INTERVAL);
        udtSend(packet);
    }
    protected void Input(Packet packet) {
        if(!Verification.isBrokenPacket(packet)){
            if(!set.add(packet.getAcknum()))
                return; // This ack packet we already received.
            // Ack packet is OK.
            messageQueue.remove(0);
            stopTimer();
            // Everything is OK then send next packet.
            nextSequenceNumber();
            sentPacket();
        }else{
            stopTimer();
            sentPacket(); // Ack packet broken, resend it.
        }
    }

    protected void TimerInterrupt() {
        sentPacket();
    }



    protected void Init() {
        sequenceNumber = -1;
    }

    private int nextSequenceNumber(){
        return ++sequenceNumber;
    }
    // ========================================
    // 不要更改此构造方法！
    public Sender(int entityName, EventList events, double pLoss, double pCorrupt, int trace, Random random) {
        super(entityName, events, pLoss, pCorrupt, trace, random);
    }
    public static final class Verification{
        public static int hash(Packet packet){
            return Objects.hash(packet.getSeqnum(),packet.getAcknum(),packet.getPayload());
        }
        public static boolean isBrokenPacket(Packet packet){
            return hash(packet) != packet.getChecksum();
        }
    }
}
