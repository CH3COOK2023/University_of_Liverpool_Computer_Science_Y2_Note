import java.util.*;

public class AutoTest {
    public static void main(String[] args) {
        for (int i = 10;i<=50;i++){
            main1(new String[]{""+i});
        }
    }
    // 6387.44
    public static int SEED = 0;
    public static int INTERVAL;
    public static final int SIMULATE_NUMBER = 100000;
    public static void main1(String[] args) {
        INTERVAL = Integer.parseInt(args[0]);
        System.out.println("INTERVAL = "+INTERVAL);
        Random rand = new Random(SEED);
        Set<Integer> generatedSeed = new HashSet<>(SIMULATE_NUMBER);
        while (generatedSeed.size()<SIMULATE_NUMBER){
            generatedSeed.add(rand.nextInt());
        }
        System.out.println();

        List<Double> score = new ArrayList<>(SIMULATE_NUMBER);
        double percentage;
        int count = -1;
        for (Integer seed : new ArrayList<>(generatedSeed)) {
            NetworkSimulator simulator  =
                    new NetworkSimulator(
                            100,
                            0.1,
                            0.1,
                            5.0,
                            0,
                            seed);
            simulator.runSimulator();
            int s = simulator.getNumberDelivered();
            if(simulator.getNumberDelivered()!=100)
            {
                System.out.println("\nTRANSMISSION FAILED");
                return;
            }
            score.add(simulator.getLastEventTime());
            percentage = (double)(++count) / (double)SIMULATE_NUMBER * 100.00;
            System.out.print(String.format("[%.2f",percentage).concat("%]\r"));
        }
        double avg = score.stream().mapToDouble(s -> s).sum() / (double) SIMULATE_NUMBER;
        System.out.printf("Score Avg = %.2f\n",avg);
    }
}
