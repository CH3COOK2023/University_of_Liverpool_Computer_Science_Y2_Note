/*************************************
 * Filename:  Receiver.java
 *************************************/

import java.util.*;
import java.util.Set;

public class Receiver extends NetworkHost {
    private final Set<Integer> set = new HashSet<>();

    // 不要改变这个构造方法
    public Receiver(int entityName, EventList events, double pLoss, double pCorrupt, int trace, Random random) {
        super(entityName, events, pLoss, pCorrupt, trace, random);
    }

    protected void Input(Packet packet) {
        if(!Sender.Verification.isBrokenPacket(packet)){
            // Packet not broken, everything OK.
            if(set.add(packet.getSeqnum()))
                deliverData(packet.getPayload()); // First time receive this new package.
            // If we received this packet before, we have to ack back.
            // If we have not received this packet before, we have to ack back too.
            Packet ackPacket = new Packet(packet);
            ackPacket.setPayload("");
            ackPacket.setChecksum(Sender.Verification.hash(ackPacket));
            udtSend(ackPacket);

        }else{
            return;
            // broken packet, do nothing.
        }
    }

    protected void Init() {
    }
}
